import React from "react";

import Dashboard from "./components/Dashboard.jsx";

const App = () => {
  return (
    <div>
      <Dashboard />
    </div>
  );
};

export default App;
